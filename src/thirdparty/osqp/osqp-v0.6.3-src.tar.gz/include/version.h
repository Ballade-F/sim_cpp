#ifndef OSQP_VERSION
#define OSQP_VERSION "v0.6.3"
#endif

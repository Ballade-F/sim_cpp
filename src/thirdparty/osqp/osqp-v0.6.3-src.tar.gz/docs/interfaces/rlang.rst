.. _rlang_interface:


R
==

The R interface is officially on CRAN and documented `here <https://cran.r-project.org/web/packages/osqp/>`_.
